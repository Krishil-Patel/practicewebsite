package com.onlineCourse.utils;
public class Constants {
    private Constants() {
    }

    public static String ROLE_USER = "user";
    public static String ROLE_ADMIN = "admin";

}
